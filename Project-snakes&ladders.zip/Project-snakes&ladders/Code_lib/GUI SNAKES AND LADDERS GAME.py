# Load tkinter module (available by default in Python) --> just import it
from tkinter import *
import tkinter.simpledialog
import tkinter.messagebox
import random

try:
    from PIL import ImageTk, Image
except ImportError:
    print("Python PIL package not found. Please install it to load images correctly.")

# Snake and Ladder game variables
dice_num = 0
SNAKE_HOLES = []
LADDER_BRIDGES = []
player_positions = []  # List to hold positions of multiple players
player_moves = []      # List to hold moves count of multiple players
player_bites = []      # List to hold bites (by snakes) count of multiple players
player_climb = []      # List to hold climbs (by ladders) count of multiple players
current_player = 0     # Index to track the current player
player_names = []      # List to hold player names
player_colors = []     # List to hold player colors

# Define a list of colors for players
PLAYER_COLORS = ['red', 'blue', 'green', 'purple']

def movePlayer():
    global current_player, dice_num, player_positions, player_moves, player_bites, player_climb

    if player_positions[current_player] == 100:
        player_positions[current_player] = 0
        player_moves[current_player] = 0
        player_bites[current_player] = 0
        player_climb[current_player] = 0

    old_player_pos = player_positions[current_player]
    new_player_pos = old_player_pos + dice_num
    additional_message = ""

    if new_player_pos > 100:
        new_player_pos = 100 - (new_player_pos - 100)

    # Check for snakes
    for idx in range(0, len(SNAKE_HOLES), 2):
        if new_player_pos == SNAKE_HOLES[idx]:
            new_player_pos = SNAKE_HOLES[idx + 1]
            player_bites[current_player] += 1
            additional_message = "Bitten | "

    # Check for ladders
    for idx in range(0, len(LADDER_BRIDGES), 2):
        if new_player_pos == LADDER_BRIDGES[idx]:
            new_player_pos = LADDER_BRIDGES[idx + 1]
            player_climb[current_player] += 1
            additional_message = "Climb | "

    # Clear old position
    if old_player_pos > 0:
        grid_array[old_player_pos - 1].config(bg="white")

    # Highlight new position with player's color
    grid_array[new_player_pos - 1].config(bg=player_colors[current_player])

    player_positions[current_player] = new_player_pos
    player_moves[current_player] += 1

    if player_positions[current_player] == 100:
        winning_message = f"{player_names[current_player]} WON Moves: {player_moves[current_player]}, Bites: {player_bites[current_player]}, Climbs: {player_climb[current_player]} WON"
        PlayerMovesLabel['text'] = winning_message
        tkinter.messagebox.showinfo("Game Over", f"{player_names[current_player]} won the game in {player_moves[current_player]} moves!")
    else:
        PlayerMovesLabel['text'] = f"{additional_message}Move: {player_moves[current_player]}, Bites: {player_bites[current_player]}, Climbs: {player_climb[current_player]}"
        current_player = (current_player + 1) % len(player_names)  # Switch to the next player

def rollTheDice():
    global dice_num
    dice_num = random.randint(1, 6)
    diceRollLabel['text'] = f"{player_names[current_player]} Rolled: {dice_num}"
    movePlayer()

def load_game_data():
    """Load snake and ladder positions from the file."""
    global SNAKE_HOLES, LADDER_BRIDGES
    try:
        file_path = r"Code_lib/snakes_ladders.txt"
        with open(file_path, "r") as file:
            for line in file:
                start, end = map(int, line.split())
                if start > end:
                    SNAKE_HOLES.extend([start, end])
                else:
                    LADDER_BRIDGES.extend([start, end])
    except FileNotFoundError:
        tkinter.messagebox.showerror("Error", "Game data file 'snakes_ladders.txt' not found.")
        exit()
    except Exception as e:
        tkinter.messagebox.showerror("Error", f"An error occurred: {e}")
        exit()

def createGUI():
    global grid_array, PlayerMovesLabel, diceRollLabel

    diceWindow = Tk()
    diceWindow.title("Snake & Ladder")
    diceWindow.resizable(width=False, height=False)
    diceWindow.config(bg='white')

    RevertLogoImage = Label(diceWindow, text="Snake & Ladder", bg='white', font=("Arial", 30))
    RevertLogoImage.grid(row=0, column=1, columnspan=10)

    PlayerMovesLabel = Label(diceWindow, text="Please enter player names in popup window", bg='white')
    PlayerMovesLabel.grid(row=1, column=1, columnspan=10)

    btnRoll = Button(diceWindow, text="Roll", command=rollTheDice, width=30)
    btnRoll.grid(row=3, column=1, columnspan=10)

    grid_array = []
    for y in range(10):
        for x in range(10):
            array_num = ((x + 1) + (y * 10))
            grid_array.append(Label(diceWindow, borderwidth=8, text=array_num))

            xx = x
            yy = y
            yy = abs(yy - 10)
            if not yy % 2:
                xx = abs(xx - 9)

            grid_array[array_num - 1].grid(row=(yy + 1) + 4, column=(xx + 1))
            grid_array[array_num - 1].config(bg='white')

            if array_num in SNAKE_HOLES:
                if SNAKE_HOLES.index(array_num) % 2 == 0:
                    grid_array[array_num - 1].config(fg="red")
                else:
                    grid_array[array_num - 1].config(fg="orange")

            if array_num in LADDER_BRIDGES:
                if LADDER_BRIDGES.index(array_num) % 2 == 0:
                    grid_array[array_num - 1].config(fg="blue")
                else:
                    grid_array[array_num - 1].config(fg="lightblue")

    num_players = tkinter.simpledialog.askinteger("Number of Players", "Please enter the number of players (2-4):", minvalue=2, maxvalue=4)
    for i in range(num_players):
        name = tkinter.simpledialog.askstring(f"Player {i + 1} Name", f"Please enter the name for Player {i + 1}:")
        player_names.append(name if name else f"Player {i + 1}")
        player_positions.append(0)  # Initialize player positions
        player_moves.append(0)      # Initialize player moves
        player_bites.append(0)      # Initialize bites count
        player_climb.append(0)      # Initialize climbs count
        player_colors.append(PLAYER_COLORS[i % len(PLAYER_COLORS)])  # Assign color to player

    PlayerMovesLabel['text'] = '- Waiting for first Roll -'
    diceRollLabel = Label(diceWindow, bg="white", text=f"Welcome {', '.join(player_names)}, Please roll your dice!")
    diceRollLabel.grid(row=2, column=1, columnspan=10)

    diceWindow.mainloop()

load_game_data()
createGUI()