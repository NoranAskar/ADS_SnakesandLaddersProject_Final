//
// Created by dalia on 11/24/2024.
//
#include "snakes_and_ladders.h"
#include <iostream>
#include <string>
using namespace std;

int main() {
    // Create a snakes_and_ladders object
    snakes_and_ladders game;
    string file_path = "../Code_lib/snakes_ladders.txt";

    // Load the snakes and ladders from the file
    game.load_from_file(file_path.c_str());

    cout << "Snake count: " << game.get_snakes() << endl;
    cout << "Ladder count: " << game.get_ladders() << endl;

    cout << "=====================================================" <<  endl;

    // Print the board to verify the loading
    game.print_board();

    game.simulateGame();

    // Test BFS shortest path
    int dice_rolls = game.bfs(1, 100);
    if (dice_rolls != -1) {
        cout << "Shortest path found in " << dice_rolls << " dice rolls." << std::endl;
    } else {
        cout << "No path found from 1 to 100." << std::endl;
    }

    return 0;
}
